//***************************
// ����̏�
//***************************

public class RecastCheck : Node
{
    public RecastCheck()
    {

    }

    public override NodeState Evaluate()
    {
        return NodeState.SUCCESS;
    }
}
