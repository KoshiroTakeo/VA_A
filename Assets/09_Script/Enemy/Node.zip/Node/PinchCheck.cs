//***************************
// �̗̓`�F�b�N
//***************************
using VR.Enemys;

public class PinchCheck : Node
{
    float currenthp;
    float seafline;

    EliteEnemy enemy;

    public PinchCheck(float _currenthp, float _seafline, EliteEnemy _enemy)
    {
        this.currenthp = _currenthp;
        this.seafline = _seafline;

        this.enemy = _enemy;
    }

    public override NodeState Evaluate()
    {
        switch(currenthp <= seafline)
        {
            case true:
                enemy.evaluteValue -= 1;
                break;
            case false:
                enemy.evaluteValue += 1;
                break;
        }

        return currenthp <= seafline ? NodeState.SUCCESS : NodeState.FAILURE;
    }
}
