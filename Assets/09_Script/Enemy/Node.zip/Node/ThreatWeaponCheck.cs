//***************************
// ����̕���g�p�x
//***************************

public class ThreatWeaponCheck : Node
{
    

    public override NodeState Evaluate()
    {
        return  1 < 0 ? NodeState.SUCCESS : NodeState.FAILURE;
    }
}
