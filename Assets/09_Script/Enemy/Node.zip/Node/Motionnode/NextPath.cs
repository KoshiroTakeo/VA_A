//*************************************
// ���̖ړI�n���o��
//*************************************
using UnityEngine;
using VR.Enemys;

public class NextPath : Node
{
    EliteEnemy owner;
    Vector3 ownerPos;

    int count;
    float distance = 1.0f;

    public NextPath(EliteEnemy _owner)
    {
        owner = _owner;
        //ownerPos = _ownerPos;
        count = 0;
    }

    public override NodeState Evaluate()
    {
        //Debug.Log(Vector3.Distance(owner.pos(), owner.CurrentPath));

        //Debug.Log(Vector3.Distance(owner.pos(), owner.CurrentPath) < distance);

        //if(Vector3.Distance(owner.pos(), owner.CurrentPath) < distance)
        //{
        //    // ���̖ړI�n��
        //    owner.PathPoint();
        //    Debug.Log("���̖ړI�n");
        //    return NodeState.SUCCESS;
        //}
        //else
        //{
        //    // �ړI�n�֐i�s��
        //    Debug.Log("�ړI�n�֏o��");
        //    return NodeState.FAILURE;
        //}


        return NodeState.SUCCESS;

    }
}
