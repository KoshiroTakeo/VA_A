//*************************************
// �ړI�n�֏o��
//*************************************
using UnityEngine;
using VR.Enemys;

public class Accel : Node
{
    EliteEnemy owner;
    Vector3 oldpos;
    Vector3 vector;

    public Accel(EliteEnemy _owner)
    {
        this.owner = _owner;
    }



    public override NodeState Evaluate()
    {
        Debug.Log("���s");

        //owner.Rigid.AddForce(vector * 1.0f, ForceMode.Acceleration);

        return NodeState.RUNNING;
    }
}
