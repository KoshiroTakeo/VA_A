//*************************************
// �S�[���̍Đݒ�͕K�v��
//*************************************
using UnityEngine;
using VR.Enemys;

public class SetGoal : Node
{
    EliteEnemy owner;
    Vector3 targetpos;

    float aria; 
    

    public SetGoal(EliteEnemy _owner, float _aria)
    {
        this.owner = _owner;
        this.aria = _aria;
    }

    public override NodeState Evaluate()
    {
        //float distance = Vector3.Distance(owner.Target.position, targetpos);

        //switch(distance > aria)
        //{
        //    // �K�v
        //    case true:
        //        Debug.Log("SetGoal / SUCCESS");
        //        targetpos = owner.Target.position;
        //        return NodeState.SUCCESS;

        //    // �s�v
        //    case false:
        //        Debug.Log("SetGoal / FAILRE");
        //        return NodeState.FAILURE;

        //}

        return NodeState.SUCCESS;
    }

    
}
