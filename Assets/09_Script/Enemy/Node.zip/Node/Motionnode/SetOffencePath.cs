//*************************************
// �S�[���ɍs���܂ł̌o�H
//*************************************
using System.Collections.Generic;
using UnityEngine;
using VR.Enemys;

public class SetOffencePath : Node
{
    Vector3 ownerpos;
    EliteEnemy owner;

    public SetOffencePath(Vector3 _ownerpos, EliteEnemy _owner)
    {
        this.ownerpos = _ownerpos;
        this.owner = _owner;
    }

    public override NodeState Evaluate()
    {
        //List<Vector3> pathlist = new List<Vector3>();

        //int r = Random.Range(15, 20);

        //for (int i = 0; i <= r; i++)
        //{
        //    float t = i / (float)r;
        //    pathlist.Add(Path(Vector3.Lerp(ownerpos, owner.Target.position, t)));
        //}

        //owner.PathPointsList(pathlist);

        //Debug.Log("SetOffencePath / SUCCESS");
        return NodeState.SUCCESS;
    }

    //Vector3 Path(Vector3 _vector3)
    //{
    //    float r = Random.Range(-1.2f, 1.2f);

    //    Vector3 vec;

    //    vec = new Vector3(_vector3.x + r, _vector3.y, _vector3.z + r);

    //    return vec;
    //}
}
