//***************************
// ����̈ʒu
//***************************
using UnityEngine;
using UnityEngine.AI;

public class TargetPosCheck : Node
{
    Transform target;
    NavMeshAgent agent;
    float range;

    public TargetPosCheck(Transform _target, NavMeshAgent _agent, float _range)
    {
        this.target = _target;
        this.agent = _agent;
        this.range = _range;
    }

    public override NodeState Evaluate()
    {
        float distance = Vector3.Distance(target.position, agent.transform.position);

        if(distance > range)
        {
            return NodeState.RUNNING;
        }
        else
        {
            return NodeState.SUCCESS;
        }
    }
}
