//***************************
// ��e���`�F�b�N
//***************************
using VR.Enemys;

public class DPSCheck : Node
{
    float dmageperscore;
    float dangerline;

    EliteEnemy enemy;

    public DPSCheck(float _dmageperscore, float _dangerline, EliteEnemy _enemy)
    {
        this.dmageperscore = _dmageperscore;
        this.dangerline = _dangerline;

        this.enemy = _enemy;
    }

    public override NodeState Evaluate()
    {
        switch(dmageperscore >= dangerline)
        {
            case true:
                enemy.evaluteValue -= 1;
                break;
            case false:
                enemy.evaluteValue += 1;
                break;
        }

        return dmageperscore >= dangerline ? NodeState.SUCCESS : NodeState.FAILURE;
    }
}
