//***************************
// �������`�F�b�N
//***************************

public class HPSCheck : Node
{
    float hitpercent;
    float goodline;

    public HPSCheck(float _hitpercent, float _goodline)
    {
        this.hitpercent = _hitpercent;
        this.goodline = _goodline;
    }

    public override NodeState Evaluate()
    {
        return  hitpercent >= goodline ? NodeState.SUCCESS : NodeState.FAILURE;
    }
}
